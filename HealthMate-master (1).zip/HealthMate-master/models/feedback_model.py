# class Feedback:
#     def __init__(self, user_id, comment, rating):
#         self.user_id = user_id
#         self.comment = comment
#         self.rating = rating 

class Feedback:
    def __init__(self, user_id, comment, rating):
        self.user_id = user_id
        self.comment = comment
        self.rating = rating

