import pymysql
 
 
def get_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='root',
        database='healthmate_schema',
        cursorclass=pymysql.cursors.DictCursor
    )


